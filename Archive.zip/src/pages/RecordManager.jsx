import React from 'react';
import { Navigate } from 'react-router-dom';

export default function RecordManager() {
  return <Navigate to="/music/releases" replace />;
}
