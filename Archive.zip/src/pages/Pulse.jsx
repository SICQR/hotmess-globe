// Pulse page - formerly Globe
// Full-screen map view with layers (people, events, care, market)
import Globe from './Globe';

export default function Pulse() {
  return <Globe />;
}